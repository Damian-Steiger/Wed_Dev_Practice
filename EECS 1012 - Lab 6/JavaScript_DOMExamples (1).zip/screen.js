/*  JavaScript Examples, EECS 1012 Fall 2018
   (CC) Michael S. Brown
	 Note that multiple line comments can this
	 type of comment */

/* declare a function named myFunction() */

function myFunction() {
	/* causes the browser to show an alert box */
	var w = screen.availWidth;
	var h = screen.availHeight;
	alert("This device has " + w + " by " + h + " pixels ");
}
