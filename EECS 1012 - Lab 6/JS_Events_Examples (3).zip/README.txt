This keyword example
example1.html
example1.js

This keyword example 2
example2.html   (without this)
example2.js
example2_v2.html  (with this)
example2_v2.hs

Example of mouseover (mouse entering an element)
example3.html
example3.js

Example of mouse entering and exiting
example4.html
example4.js
example4_v2.html (only 1 function and using event to decide which event occurred)
example4_v2.js

Mouse motion events (getting mouse positions)
example5.html
example5.js

Keyboard event  (clears a "text area" when the keyboard is clicked.)
** This example also has an example of stopping an event handler by unObserving an event
example6.html
example6.js

Timer
example7.html
example7.js

Timer with mouse enter/exit click
example7_v2.html
example7_v2.js

Submit Form example
example8.html
example8.js

Moving Card Example (Advanced, but awesome)
example9.html
example9.js
example9.css
example9_debug.html (prints out some variable info to help understand the program)
example9_debug.js
